using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    bool gameHasEnded = false;

    public float restartDelay = 1f;

    public GameObject completeLevelUI;
    public GameObject sumUI;
    public GameObject scoreUI;
    public GameObject numbersUI;


    public void CompleteLevel ()
    {
        completeLevelUI.SetActive(true);
        sumUI.SetActive(false);
        scoreUI.SetActive(false);
        numbersUI.SetActive(false);
    }

    public void EndGame ()
    {
        if (!gameHasEnded)
        {
            //gameHasEnded = true;
            //Debug.Log("GAME OVER!");
            Invoke("Restart", restartDelay);
        }        
    }
    void Restart()
    {
        string gameName = SceneManager.GetActiveScene().name;
        //SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        if (gameName == "EasyLevel")
        {
            FindObjectOfType<Score>().Restart();
        }
        else if (gameName == "HardLevel")
        { FindObjectOfType<ScoreHard>().Restart(); }
    }
}
