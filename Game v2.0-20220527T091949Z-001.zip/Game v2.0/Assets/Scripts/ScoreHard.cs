using UnityEngine;
using UnityEngine.UI;

public class ScoreHard : MonoBehaviour
{
    public Transform player;
    public Text sumText;
    public Text numbText;
    public Text scoreText;
    public Rigidbody rb;
    public Transform obstacle;
    public Transform line;

    bool x2 = true, x3 = true, x4 = true, x5 = true, x6 = true, x7 = true, x8 = true, x9 = true, x10 = true, x11 = true;
    int temp = 0;
    int sum = 1;
    int x = 1;
    string z;
    public void Restart()
    {
        temp--;
        FindObjectOfType<PlayerMovement>().Restart(player);
        //transform.position = new Vector3(0, (float)1.1, 0);
    }
    public void Sum(string z)
    {
        if (z == "*") sum *= x;
        if (z == "+") sum += x;
        if (z == "-") sum -= x;
        if (z == "/") sum /= x;
    }
    public void Znak(int t1, int t2, string s1, string s2)
    {
        if (s1 == "/" && s2 == "/")
        {
            if (sum / t1 > sum / t2)
            {
                obstacle.transform.position = new Vector3((float)3.85, (float)1, (int)player.position.z + 30);
                line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
                x = t1;
                z = s1;
            }
            else
            {
                obstacle.transform.position = new Vector3((float)-3.85, (float)1, (int)player.position.z + 30);
                line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
                x = t2;
                z = s2;
            }
        }
        else if (s1 == "/" && s2 == "-")
        {
            if (sum / t1 > sum - t2)
            {
                obstacle.transform.position = new Vector3((float)3.85, (float)1, (int)player.position.z + 30);
                line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
                x = t1;
                z = s1;
            }
            else
            {
                obstacle.transform.position = new Vector3((float)-3.85, (float)1, (int)player.position.z + 30);
                line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
                x = t2;
                z = s2;
            }
        }
        else if (s1 == "-" && s2 == "/")
        {
            if (sum - t1 > sum / t2)
            {
                obstacle.transform.position = new Vector3((float)3.85, (float)1, (int)player.position.z + 30);
                line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
                x = t1;
                z = s1;
            }
            else
            {
                obstacle.transform.position = new Vector3((float)-3.85, (float)1, (int)player.position.z + 30);
                line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
                x = t2;
                z = s2;
            }
        }
        else
        {
            if (sum - t1 > sum - t2)
            {
                obstacle.transform.position = new Vector3((float)3.85, (float)1, (int)player.position.z + 30);
                line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
                x = t1;
                z = s1;
            }
            else
            {
                obstacle.transform.position = new Vector3((float)-3.85, (float)1, (int)player.position.z + 30);
                line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
                x = t2;
                z = s2;
            }
        }
    }
    public void ThreeInOne()
    {
        if (x2) { temp++; Sum(z); }
        x2 = false;
        int t1 = Random.Range(1, 100);
        int t2 = Random.Range(1, 100);
        if (t1 == t2) t2 = Random.Range(50, 100);
        string s1;
        string s2;
        sumText.text = sum.ToString();
        if ((sum % t2) == 0 && (sum % t1) == 0)
        {
            numbText.text = ("/" + t1.ToString() + "           " + "/" + t2.ToString());
            s1 = "/";
            s2 = "/";
        }
        else if ((sum % t1) == 0)
        {
            s1 = "/";
            s2 = "-";
            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
            Znak(t1, t2, s1, s2);
        }
        else if ((sum % t2) == 0)
        {
            numbText.text = ("-" + t1.ToString() + "           " + "/" + t2.ToString());
            s1 = "-";
            s2 = "/";
        }
        else
        {
            s1 = "-";
            s2 = "-";
            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
            Znak(t1, t2, s1, s2);
        }
    }
    public void MultiAndMulti()
    {
        if (x2) { temp++; Sum(z); }
        x2 = false;
        int t1 = Random.Range(3, 7);
        int t2 = Random.Range(2, 7);
        if (t1 == t2) t2 = Random.Range(2, 8);
        sumText.text = sum.ToString();
        numbText.text = ("*" + t1.ToString() + "           " + "*" + t2.ToString());
        if (sum * t1 > sum * t2)
        {
            obstacle.transform.position = new Vector3((float)3.85, (float)1, (int)player.position.z + 30);
            line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
            x = t1;
            z = "*";
        }
        else
        {
            obstacle.transform.position = new Vector3((float)-3.85, (float)1, (int)player.position.z + 30);
            line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
            x = t2;
            z = "*";
        }
    }
    public void SumAndMulti()
    {
        if (x2) { temp++; Sum(z); }
        x2 = false;
        int t1 = Random.Range(50, 200);
        int t2 = Random.Range(2, 7);
        if (t1 == t2) t1 = Random.Range(50, 200);
        sumText.text = sum.ToString();
        numbText.text = ("+" + t1.ToString() + "           " + "*" + t2.ToString());
        if (sum + t1 > sum * t2)
        {
            obstacle.transform.position = new Vector3((float)3.85, (float)1, (int)player.position.z + 30);
            line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
            x = t1;
            z = "+";

        }
        else
        {
            obstacle.transform.position = new Vector3((float)-3.85, (float)1, (int)player.position.z + 30);
            line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
            x = t2;
            z = "*";
        }
    }
    public void MultiAndSum()
    {
        if (x2) { temp++; Sum(z); }
        x2 = false;
        int t1 = Random.Range(2, 7);
        int t2 = Random.Range(50, 300);
        if (t1 == t2) t2 = Random.Range(50, 300);
        sumText.text = sum.ToString();
        numbText.text = ("*" + t1.ToString() + "           " + "+" + t2.ToString());
        if (sum * t1 > sum + t2)
        {
            obstacle.transform.position = new Vector3((float)3.85, (float)1, (int)player.position.z + 30);
            line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
            x = t1;
            z = "*";

        }
        else
        {
            obstacle.transform.position = new Vector3((float)-3.85, (float)1, (int)player.position.z + 30);
            line.transform.position = new Vector3((float)0.1, (float)0.6, (int)player.position.z + 30);
            x = t2;
            z = "+";
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (player.position.z >= 30)
        {
            scoreText.text = temp.ToString();
            if ((int)player.position.z % 30 == 0)
            {
                int operation = 4;
                if (System.String.Compare(sumText.text, "500") < 0)
                {
                    operation = Random.Range(1, 4);
                }
                if (operation == 1)
                {
                    MultiAndSum();
                }
                else if (operation == 2)
                {
                    SumAndMulti();
                }
                else if (operation == 3)
                {
                    MultiAndMulti();
                }
                else {ThreeInOne();}
            }
            if ((int)player.position.z % 32 == 0)
            {
                x2 = true;
            }
        }
    }
}
        //    if ((int)player.position.z == 80)
        //    {
        //        if (x3) { temp++; Sum(z); }
        //        x3 = false; 
        //        int t1 = Random.Range(2, 50);
        //        int t2 = Random.Range(2, 50);
        //        if (t1 == t2) t2 = Random.Range(1, 50);
        //        string s1;
        //        string s2;
        //        sumText.text = sum.ToString();
        //        if ((sum % t2) == 0 && (sum % t1) == 0)
        //        {
        //            numbText.text = ("/" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "/";
        //        }
        //        else if ((sum % t1) == 0)
        //        {
        //            s1 = "/";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 110);
        //        }
        //        else if ((sum % t2) == 0)
        //        {
        //            numbText.text = ("-" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "-";
        //        }
        //        else
        //        {
        //            s1 = "-";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 110);
        //        }

        //    }
        //    if ((int)player.position.z == 110)
        //    {
        //        if (x4) { temp++; Sum(z); }
        //        x4 = false;
        //        int t1 = Random.Range(2, 50);
        //        int t2 = Random.Range(2, 50);
        //        if (t1 == t2) t2 = Random.Range(1, 50);
        //        string s1;
        //        string s2;
        //        sumText.text = sum.ToString();
        //        if ((sum % t2) == 0 && (sum % t1) == 0)
        //        {
        //            numbText.text = ("/" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "/";
        //        }
        //        else if ((sum % t1) == 0)
        //        {
        //            s1 = "/";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 140);
        //        }
        //        else if ((sum % t2) == 0)
        //        {
        //            numbText.text = ("-" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "-";
        //        }
        //        else
        //        {
        //            s1 = "-";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 140);
        //        }
        //    }
        //    if ((int)player.position.z == 140)
        //    {
        //        if (x5) { temp++; Sum(z); }
        //        x5 = false;
        //        int t1 = Random.Range(1, 5);
        //        int t2 = Random.Range(1, 500);
        //        if (t1 == t2) t2 = Random.Range(1, 50);
        //        sumText.text = sum.ToString();
        //        numbText.text = ("*" + t1.ToString() + "           " + "+" + t2.ToString());
        //        if (sum * t1 > sum + t2)
        //        {
        //            obstacle.transform.position = new Vector3((float)3.85, (float)1, 170);
        //            x = t1;
        //            z = "*";
        //        }
        //        else
        //        {
        //            obstacle.transform.position = new Vector3((float)-3.85, (float)1, 170);
        //            x = t2;
        //            z = "+";
        //        }
        //    }
        //    if ((int)player.position.z == 170)
        //    {
        //        if (x6) { temp++; Sum(z); }
        //        x6 = false;
        //        int t1 = Random.Range(2, 100);
        //        int t2 = Random.Range(2, 100);
        //        if (t1 == t2) t2 = Random.Range(1, 100);
        //        string s1;
        //        string s2;
        //        sumText.text = sum.ToString();

        //        if ((sum % t2) == 0 && (sum % t1) == 0)
        //        {
        //            numbText.text = ("/" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "/";
        //        }
        //        else if((sum % t1) == 0)
        //        {
        //            s1 = "/";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 200);
        //        }
        //        else if ((sum % t2) == 0)
        //        {
        //            numbText.text = ("-" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "-";
        //        }
        //        else
        //        {
        //            s1 = "-";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 200);
        //        }
        //    }
        //    if ((int)player.position.z == 200)
        //    {
        //        if (x7) { temp++; Sum(z); }
        //        x7 = false;
        //        int t1 = Random.Range(2, 100);
        //        int t2 = Random.Range(2, 100);
        //        if (t1 == t2) t2 = Random.Range(1, 100);
        //        string s1;
        //        string s2;
        //        sumText.text = sum.ToString();

        //        if ((sum % t2) == 0 && (sum % t1) == 0)
        //        {
        //            numbText.text = ("/" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "/";
        //        }
        //        else if((sum % t1) == 0)
        //        {
        //            s1 = "/";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 230);
        //        }
        //        else if ((sum % t2) == 0)
        //        {
        //            numbText.text = ("-" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "-";
        //        }
        //        else
        //        {
        //            s1 = "-";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 230);
        //        }
        //    }
        //    if ((int)player.position.z == 230)
        //    {
        //        if (x8) { temp++; Sum(z); }
        //        x8 = false;
        //        int t1 = Random.Range(1, 5);
        //        int t2 = Random.Range(1, 500);
        //        sumText.text = sum.ToString();
        //        numbText.text = ("*" + t1.ToString() + "           " + "+" + t2.ToString());
        //        if (sum * t1 > sum + t2)
        //        {
        //            obstacle.transform.position = new Vector3((float)3.85, (float)1, 260);
        //            x = t1;
        //            z = "*";
        //        }
        //        else
        //        {
        //            obstacle.transform.position = new Vector3((float)-3.85, (float)1, 260);
        //            x = t2;
        //            z = "+";
        //        }
        //    }
        //    if ((int)player.position.z == 260)
        //    {
        //        if (x9) { temp++; Sum(z); }
        //        x9 = false;
        //        int t1 = Random.Range(3, 6);
        //        int t2 = Random.Range(1, 10);
        //        if (t1 == t2) t2 = Random.Range(1, 10);
        //        sumText.text = sum.ToString();
        //        numbText.text = ("*" + t1.ToString() + "           " + "*" + t2.ToString());
        //        if (sum * t1 > sum * t2)
        //        {
        //            obstacle.transform.position = new Vector3((float)3.85, (float)1, 290);
        //            x = t1;
        //            z = "*";
        //        }
        //        else
        //        {
        //            obstacle.transform.position = new Vector3((float)-3.85, (float)1, 290);
        //            x = t2;
        //            z = "*";
        //        }
        //    }
        //    if ((int)player.position.z == 290)
        //    {
        //        if (x10) { temp++; Sum(z); }
        //        x10 = false;
        //        int t1 = Random.Range(2, 100);
        //        int t2 = Random.Range(2, 100);
        //        if (t1 == t2) t2 = Random.Range(1, 100);
        //        string s1;
        //        string s2;
        //        sumText.text = sum.ToString();

        //        if ((sum % t2) == 0 && (sum % t1) == 0)
        //        {
        //            numbText.text = ("/" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "/";
        //        }
        //        else if((sum % t1) == 0)
        //        {
        //            s1 = "/";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 320);
        //        }
        //        else if ((sum % t2) == 0)
        //        {
        //            numbText.text = ("-" + t1.ToString() + "           " + "/" + t2.ToString());
        //            s2 = "/";
        //            s1 = "-";
        //        }
        //        else
        //        {
        //            s1 = "-";
        //            s2 = "-";
        //            numbText.text = (s1 + t1.ToString() + "           " + s2 + t2.ToString());
        //            Znak(t1, t2, s1, s2, 320);
        //        }
        //    }
        //    if ((int)player.position.z == 320)
        //    {
        //        if (x11) { temp++; Sum(z); }
        //        x11 = false;
        //        int t1 = Random.Range(1, 100);
        //        int t2 = Random.Range(1, 100);
        //        if (t1 == t2) t2 = Random.Range(1, 100);
        //        sumText.text = sum.ToString();
        //        numbText.text = ("+" + t1.ToString() + "           " + "+" + t2.ToString());
        //        if (sum + t1 > sum + t2)
        //        {
        //            obstacle.transform.position = new Vector3((float)3.85, (float)1, 350);
        //            x = t1;
        //            z = "+";
        //        }
        //        else
        //        {
        //            obstacle.transform.position = new Vector3((float)-3.85, (float)1, 350);
        //            x = t2;
        //            z = "+";
        //        }
        //    }
        //}
    

