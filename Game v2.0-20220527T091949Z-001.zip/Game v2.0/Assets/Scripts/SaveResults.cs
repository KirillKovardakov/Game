using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Data;
using UnityEngine.UI;

public class SaveResults : MonoBehaviour
{
    public InputField inputName;
    public Text score;
    public void Save()
    {
        MyDataBase.SetTable($"INSERT INTO users (nickname, score, password) VALUES('{inputName.text}', {score.text}, 'qwerty'); ");
    }
}