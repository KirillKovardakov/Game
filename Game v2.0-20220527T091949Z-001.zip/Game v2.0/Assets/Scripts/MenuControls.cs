using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Data;
using UnityEngine.UI;

public class MenuControls : MonoBehaviour
{
    public void PlayPressed()
    {
        SceneManager.LoadScene("EasyLevel");
    }
    public void PlayHardLevelPressed()
    {
        SceneManager.LoadScene("HardLevel");
    }
    public void ExitPressed()
    {
        Debug.Log("Exit pressed!");
        Application.Quit();
    }
    public void ResetPressed()
    {
        SceneManager.LoadScene("Menu");
    }
}
