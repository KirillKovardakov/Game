using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FindToNickname : MonoBehaviour
{
    //public InputField inputName;
    //public Text score;
    //public void Save()
    //{
    //    DataTable scoreboard = MyDataBase.GetTable($"Select * FROM users WHERE nickname = '{inputName}'; ");
    //    foreach (var item in collection)
    //    {
    //        score.text = score.text + ($"����� {scoreboard.Rows[0][1].ToString()} ������ {scoreboard.Rows[0][2].ToString()} �����.");
    //    }
        
    //}
}
