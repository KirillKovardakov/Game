using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Visibility : MonoBehaviour
{
    public MeshRenderer visibol;
    public void Visiboly()
    {
        visibol.enabled = !visibol.enabled;
    }
}
