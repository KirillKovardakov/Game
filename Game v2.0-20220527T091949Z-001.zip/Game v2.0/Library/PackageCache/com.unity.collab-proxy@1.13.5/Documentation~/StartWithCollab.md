# Getting started with Collaborate

Collaborate makes it easy for teams to save, share, and sync their Unity projects with others, regardless of location. It is cloud-enabled and built directly into Unity. For more information, see the [Unity Collaborate manual](https://docs.unity3d.com/Manual/UnityCollaborate.html).
